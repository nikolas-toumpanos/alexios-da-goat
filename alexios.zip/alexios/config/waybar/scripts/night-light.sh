#!/bin/bash

# Check if hyprsunset is running
if pgrep -x "hyprsunset" > /dev/null
then
    pkill -x "hyprsunset"
else
    hyprsunset --temperature 1500 &
fi
